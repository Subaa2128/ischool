export const academicYearOptions = [
  { value: "2023-2024", label: "2023-2024" },
  { value: "2024-2025", label: "2024-2025" },
];

export const gradeOptions = [
  { value: "A", label: "A" },
  { value: "B", label: "B" },
];

export const Headers = [
  "admission",
  "student",
  "parent",
  "siblings",
  "previousStudy",
  "upload",
];

export const gender = [
  { value: "male", label: "Male" },
  { value: "female", label: "Female" },
];

export const motherTongue = [
  { value: "tamil", label: "Tamil" },
  { value: "telugu", label: "Telugu" },
  { value: "malayalam", label: "Malayalam" },
  { value: "english", label: "English" },
  { value: "hindi", label: "Hindi" },
];

export const community = [
  { value: "sc", label: "SC" },
  { value: "st", label: "ST" },
  { value: "obc", label: "OBC" },
  { value: "mbc", label: "MBC" },
  { value: "gen", label: "GEN" },
  { value: "others", label: "Others" },
];

export const brotherSister = [
  { value: "brother", label: "Brother" },
  { value: "sister", label: "Sister" },
];

export const matric = [
  { value: "matric", label: "Matric" },
  { value: "cbse", label: "CBSC" },
  { value: "cse", label: "CSE" },
  { value: "other", label: "Other" },
];
