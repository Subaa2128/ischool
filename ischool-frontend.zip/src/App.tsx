import React, { Fragment } from "react";
import Header from "./Components/Header";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./Pages/Login";
import Payment from "./Pages/Payment";
import RecentTransaction from "./Pages/RecentTransaction";
import PaymentHistory from "./Pages/PaymentHistory";
import NewAdmission from "./Pages/NewAdmission";

const App: React.FC = () => {
  return (
    <Fragment>
      <Header />
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/payment" element={<Payment />} />
        <Route path="/recenttransaction" element={<RecentTransaction />} />
        <Route path="/paymenthistory/:id" element={<PaymentHistory />} />
        <Route path="/newadmission" element={<NewAdmission />} />
      </Routes>
    </Fragment>
  );
};

export default App;
