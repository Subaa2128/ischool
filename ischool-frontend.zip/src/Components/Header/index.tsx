import React from "react";

import "./Header.scss";
import Button from "../Button";

import PlusIcon from "../../assets/Icons/plus.svg";
import { ReactComponent as HeaderLogo } from "../../assets/Logos/ischool-logo.svg";
import { useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  return (
    <div className="header-container">
      <div className="mx">
        <div className="header-wrapper">
          <HeaderLogo />
          <Button
            children="New Admission"
            variant="primary"
            leftIcon={<img src={PlusIcon} alt="alt" />}
            onClick={() => navigate("/newadmission")}
          />
        </div>
      </div>
    </div>
  );
};

export default Header;
