import React, { useState } from "react";
import "./Search.scss";
import Button from "../Button";

import { ReactComponent as SearchIcon } from "../../assets/Icons/search.svg";
import { ReactComponent as FilterIcon } from "../../assets/Icons/Frame 84.svg";

interface ISearch {
  setSearchData: React.Dispatch<React.SetStateAction<string>>;
  searchData: string;
}
const Search: React.FC<ISearch> = ({ setSearchData, searchData }) => {
  const [openFilter, setOpenFilter] = useState(false);

  return (
    <div className={`search-container ${openFilter ? "open-filter" : ""}`}>
      <div className={`search-box ${openFilter ? "search-box-minimized" : ""}`}>
        <SearchIcon />
        <input
          value={searchData}
          type="text"
          placeholder="Search by receipt no, admission no, name"
          onChange={(e) => setSearchData(e.target.value)}
        />
      </div>
      {openFilter && (
        <div className="filter-options">
          <input type="date" placeholder="From" />
          <input type="date" placeholder="To" />
          <select name="" id=""></select>
          <select name="" id=""></select>
        </div>
      )}
      <FilterIcon
        width={openFilter ? 60 : 40}
        height={openFilter ? 60 : 40}
        onClick={() => setOpenFilter((m) => !m)}
        style={{ cursor: "pointer" }}
      />
      <Button variant="primary">Apply</Button>
    </div>
  );
};

export default Search;
